package com.example.techtext1.Notifications;

public class MyResponse {

    public int success;
}
