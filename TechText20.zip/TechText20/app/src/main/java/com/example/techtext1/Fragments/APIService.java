package com.example.techtext1.Fragments;

import com.example.techtext1.Notifications.MyResponse;
import com.example.techtext1.Notifications.Sender;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.Headers;
import retrofit2.http.POST;

public interface APIService {
    @Headers(
            {
                    "Content-Type:application/json",
                    "Authorization:key=AAAAdcMR-t0:APA91bFPA_hw2_IahUlKC0sNNM9Exkrjq6nVQwVsfMQLfpPef6NRZcwvqjeyd3DbAseD_iWdlUcA14RAirdvXutiNBfT5pC2D9GKLB2BdkLeTZiF8w8ahB_ap2CxJIas6_1lJeBo8urA"
            }
    )

    @POST("fcm/send")
    Call<MyResponse> sendNotification(@Body Sender body);
}
